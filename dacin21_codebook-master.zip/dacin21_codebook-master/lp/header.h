
// Linear programming in low dimension
// Uses Bigintegers for exact calculations

#include <algorithm>
#include <bitset>
#include <cassert>
#include <chrono>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <random>
#include <vector>


namespace lowdim_lp{
