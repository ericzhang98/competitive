# Code collection of dacin21
Code may be broken or inefficient.
USE CODE AT OWN RISK!